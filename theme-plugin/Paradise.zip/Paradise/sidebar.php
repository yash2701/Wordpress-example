<div class="col-sm-3 col-sm-offset-1 blog-sidebar">
    <div class="sidebar-module">
		<h4><?php _e('Archives'); ?></h4>
		<ol class="list-unstyled">
			<li><?php wp_get_archives(); ?></li>
			
		</ol>
	</div>

</div><!-- /.blog-sidebar -->