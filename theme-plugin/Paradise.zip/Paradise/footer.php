

</div><!-- /.container -->
</div>

<footer class="blog-footer">
    <p>Copyright © 2019</p>
    <p><a href="#">Back to top</a></p>
</footer>

<?php wp_footer(); ?>
</body>
</html>
